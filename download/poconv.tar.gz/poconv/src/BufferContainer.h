//
//	BufferContainer.h (poconv/��ȥХåե�����)
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#ifndef _POCONV_BUFFERCONTAINER_H
#define _POCONV_BUFFERCONTAINER_H

#include  <basic.h>
#include  <btron/btron.h>
#include  <btron/dp.h>
#include  <tad.h>

namespace PoConv {

// ------------------------------------------------------ class BufferContainer
class BufferContainer {
  public:
    // constructor
    BufferContainer();

    // destructor
    ~BufferContainer();

    // �ꥻ�å�
    void  reset();

    // �Хåե���������
    void  resize(::W size);

    // �ɤ߹���
    bool  readB(::B* val) { return read(val, sizeof(::B), 0); }
    bool  readH(::H* val) { return read(val, sizeof(::H), 0); }
    bool  readW(::W* val) { return read(val, sizeof(::W), 0); }
    bool  readUB(::UB* val) { return read(val, sizeof(::UB), 0); }
    bool  readUH(::UH* val) { return read(val, sizeof(::UH), 0); }
    bool  readUW(::UW* val) { return read(val, sizeof(::UW), 0); }
    bool  readTC(::TC* val) { return read(val, sizeof(::TC), 0); }
    bool  readUNITS(::UNITS* val) { return read(val, sizeof(::UNITS), 0); }
    bool  readCOLOR(::COLOR* val) { return read(val, sizeof(::COLOR), 0); }
    bool  read(void* bytes, ::W length, ::W* readed); // Ǥ��

    // �Хåե����̼���
    ::W length() const { return (len_ - current_); }

    // �Х��ʥ������
    void* bytes() const { return (buffer_ + current_); }

  private:
    ::W len_;
    ::W size_;
    ::W current_;
    unsigned char* buffer_;
};

} // namespace PoConv

#endif  // _POCONV_BUFFERCONTAINER_H
