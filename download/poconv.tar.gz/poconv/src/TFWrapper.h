//
//	TFWrapper.h (poconv/libtf wrapper)
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#ifndef _POCONV_TFWRAPPER_H
#define _POCONV_TFWRAPPER_H

#include  <basic.h>
#include  <btron/tf.h>

namespace PoConv {

// ------------------------------------------------------------ class TFWrapper
class TFWrapper {
  public:
    // constructor
    TFWrapper();

    // destructor
    ~TFWrapper();

    // ID ����
    ::W getID(::W id, const char* str) const;

    // �Ѵ�����
    void  setConvertTo(const char* str);
    void  setConvertToOption(const char* str, int val);

    // �Ѵ�
    bool  append(const void* data, int len);

    // ����
    const void* bytes() const { return buffer_ + refer_; }
    const unsigned int length() const { return length_ - refer_; }

    // ����
    void  clear(unsigned int len);

  private:
    ::TF_CTX  ctx_;
    unsigned char* buffer_;
    unsigned int   length_;
    unsigned int   refer_;
};

} // namespace PoConv

#endif  // _POCONV_TFWRAPPER_H
