//
//	Units.h (poconv/�������)
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#ifndef _POCONV_UNITS_H
#define _POCONV_UNITS_H

#include  <basic.h>
#include  <btron/dp.h>
#include  <tad.h>
#include  <bstdlib.h>
#include  <bstring.h>
#include  <tstring.h>

#include  <new>
#include  <list>
#include  <vector>

namespace PoConv {

// ------------------------------------------------------------- class UnitBase
class UnitBase {
  public:
    // constructor
    UnitBase() : count_(0) { }

    // destructor
    virtual ~UnitBase() { }

    // �ݻ�
    void  retain() throw() try { ++count_; } catch (...) { }

    // ����
    void  release() throw() try
      { --count_; if (count_ == 0) { delete this; } } catch (...) { }

  private:
    unsigned int count_;
};


// ------------------------------------------------------------ class UnitColor
class UnitColor : public UnitBase {
  public:
    // constructor
    UnitColor()
      : UnitBase(),
        color_(0), trans_(false), drop_(false), mask_(false) { }

    // destructor
    virtual ~UnitColor() { }

    // ����
    void  setColor(::COLOR color) { color_ = color; }
    void  setTrans(bool flag) { trans_ = flag; }
    void  setDrop(bool flag) { drop_ = flag; }
    void  setMask(bool flag) { mask_ = flag; }

    // ����
    ::COLOR getColor() const { return color_; }
    bool    getTrans() const { return trans_; }
    bool    getDrop() const { return drop_; }
    bool    getMask() const { return mask_; }

  private:
    ::COLOR color_;
    bool    trans_;
    bool    drop_;
    bool    mask_;
};


// ----------------------------------------------------- class UnitColorPattern
class UnitColorPattern : public UnitBase {
  public:
    // constructor
    UnitColorPattern(::UH width, ::UH height)
      : UnitBase(),
        width_(width), height_(height),
        rowBytes_(width + (width & 1)),
        size_(rowBytes_ * height), pixelMap_(0)
        { pixelMap_ = new unsigned char[size_]; }

    // destructor
    virtual ~UnitColorPattern() { delete[] pixelMap_; }

    // ����
    void  setPixelMap(const unsigned char* pixel)
      { for (::UH y(0); y < height_; ++y) {
          ::memcpy(&pixelMap_[y * rowBytes_], &pixel[y * rowBytes_], width_);
        } }
 

    // ����
    const ::UH  getWidth() const { return width_; }
    const ::UH  getHeight() const { return height_; }
    const unsigned int getSize() const { return size_; }
    const unsigned char* getPixelMap() const { return pixelMap_; }

  private:
    const ::UH  width_;
    const ::UH  height_;
    const unsigned int rowBytes_;
    const unsigned int size_;
    unsigned char* pixelMap_;
};


// ------------------------------------------------------- class UnitImageLayer
class UnitImageLayer : public UnitBase {
  public:
    // constructor
    UnitImageLayer(::UH width, ::UH height)
      : UnitBase(),
        width_(width), height_(height),
        rowBytes_(width + (width & 1)),
        size_(rowBytes_ * height_), pixelMap_(0),
        name_(0), nameLen_(0), visible_(true)
#if 0
      { pixelMap_ = new unsigned char[size_]; }
#else   // 0
      { pixelMap_ = static_cast<unsigned char*>(::Smalloc(size_));
        if (pixelMap_ == 0) { throw std::bad_alloc(); } }
#endif  // 0

    // destructor
#if 0
    virtual ~UnitImageLayer() { delete[] pixelMap_; delete[] name_; }
#else   // 0
    virtual ~UnitImageLayer()
      { if (pixelMap_ != 0) { ::Sfree(pixelMap_); } delete[] name_; }
#endif  // 0

    // ����
    void  setVisible(bool flag)
      { visible_ = flag; }
    void  setPixelMap(const unsigned char* pixel)
      { ::memcpy(pixelMap_, pixel, size_); }
    void  setName(const ::TC* name, int len)
      { delete[] name_; name_ = 0;
        name_ = new ::TC[len];
        ::tc_strncpy(name_, name, len); nameLen_ = len; }

    // ����
    const ::TC* getName() const { return name_; }
    const int   getNameLength() const { return nameLen_; }
    const bool  getVisible() const { return visible_; }
    const ::UH  getWidth() const { return width_; }
    const ::UH  getHeight() const { return height_; }
    const unsigned int getSize() const { return size_; }
    const unsigned char* getPixelMap() const { return pixelMap_; }

  private:
    const ::UH  width_;
    const ::UH  height_;
    const unsigned int rowBytes_;
    const unsigned int size_;
    unsigned char* pixelMap_;
    ::TC* name_;
    int   nameLen_;
    bool  visible_;
};


// ---------------------------------------------------------- class UnitFactory
class UnitFactory {
  public:
    // ���μ���
    static UnitFactory& getInstance()
      { if (onlyOneInstance_ == 0) { onlyOneInstance_ = new UnitFactory(); }
        return *onlyOneInstance_; }

    // �����˴�
    static void cleanup() throw() try
      { delete onlyOneInstance_; onlyOneInstance_ = 0; } catch (...) { }

    // ��������
    UnitColor* createColor() const
      { return new UnitColor(); }
    UnitColorPattern* createColorPattern(::UH width, ::UH height) const
      { return new UnitColorPattern(width, height); }
    UnitImageLayer* createImageLayer(::UH width, ::UH height) const
      { return new UnitImageLayer(width, height); }

  private:
    static UnitFactory* onlyOneInstance_;

    // constructor
    UnitFactory() { }

    // destructor
    ~UnitFactory() { }
};


// -------------------------------------------------------- class UnitContainer
class UnitContainer {
  public:
    typedef std::list<UnitBase*>        Container;
    typedef Container::iterator         Iter;
    typedef std::vector<UnitBase*>      PaletteContainer;
    typedef PaletteContainer::iterator  PaletteIter;

  public:
    // constructor
    UnitContainer() : palette_(), pattern_(), layer_() { }

    // destructor
    ~UnitContainer()
      { clearPalette(palette_); clear(pattern_); clear(layer_); }

    // �ɲ�
    void  appendPalette(UnitBase* unit)
      { unit->retain(); palette_.push_back(unit); }
    void  appendPattern(UnitBase* unit)
      { unit->retain(); pattern_.push_back(unit); }
    void  appendLayer(UnitBase* unit)
      { unit->retain(); layer_.push_back(unit); }

    // �ѥ�åȼ���
    PaletteIter getBeginPalette() { return palette_.begin(); }
    PaletteIter getNextPalette(PaletteIter iter) { return ++iter; }
    PaletteIter getEndPalette() { return palette_.end(); }
    UnitColor* getColor(int index)
      { return static_cast<UnitColor*>(palette_[index]); }
     
    // ���顼�ѥ��������
    Iter getBeginPattern() { return pattern_.begin(); }
    Iter getNextPattern(Iter iter) { return ++iter; }
    Iter getEndPattern() { return pattern_.end(); }

    // �쥤�䡼����
    Iter getBeginLayer() { return layer_.begin(); }
    Iter getNextLayer(Iter iter) { return ++iter; }
    Iter getEndLayer() { return layer_.end(); }

  private:
    PaletteContainer  palette_;         // �ѥ�å�
    Container pattern_;                 // ���顼�ѥ�����
    Container layer_;                   // �쥤�䡼

    // ����
    void  clearPalette(PaletteContainer& cont) throw() try {
      for (PaletteIter iter(cont.begin()); iter != cont.end(); ++iter) {
        (*iter)->release();
      }
    } catch (...) {
    }
    void  clear(Container& cont) throw() try {
      for (Iter iter(cont.begin()); iter != cont.end(); ++iter) {
        (*iter)->release();
      }
    } catch (...) {
    }
};

} // namespace PoConv

#endif  // _POCONV_UNITS_H
