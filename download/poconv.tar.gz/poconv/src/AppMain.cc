//
//	AppMain.cc (poconv/Application Main)
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#include  "AppMain.h"

#include  <bstdio.h>

#include  "InputFile.h"
#include  "OutputFile.h"
#include  "TADParser.h"

namespace PoConv {

// ----------------------------------------------------- AppMain �� public �ؿ�
//
// constructor
//
AppMain::AppMain(int argc, ::TC** argv)
  : option_(argc, argv), container_(), hUnit_(0), vUnit_(0)
{
  // ���⤷�ʤ�
  ;
}


//
// destructor
//
AppMain::~AppMain()
{
  // ���⤷�ʤ�
  ;
}


//
// �¹�
//
void  AppMain::main()
{
  printf("start.\n");

  // �ɤ߹���
  input();

  // �񤭹���
  output();

  printf("finish.\n");

  return;
}


// ---------------------------------------------------- AppMain �� private �ؿ�
//
// �ɤ߹���
//
void  AppMain::input()
{
  printf("data reading...\n");

  InputFile inFile(option_.getInputPath());
  while (inFile.parseRecord()) {
    // 1�쥳�����ɤ߹���
    const ::UH  subType(inFile.readRecord());

    // TAD ����/�����������Ѵ�
    TADParser parser(subType, inFile.getBuffer());

    parser.main();

    // ��̼���
    parser.getResult(container_);
    if (parser.getHUnit() != 0) {
      hUnit_ = parser.getHUnit();
    }
    if (parser.getVUnit() != 0) {
      vUnit_ = parser.getVUnit();
    }
  }

  return;
}


//
// �񤭹���
//
void  AppMain::output()
{
  printf("data converting and writing.\n");

  OutputFile outFile(option_.getOutputPath(), container_, hUnit_, vUnit_);

  outFile.main();

  return;
}

} // namespace PoConv
