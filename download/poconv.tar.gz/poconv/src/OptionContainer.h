//
//	OptionContainer.h (poconv/Application Main)
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#ifndef _POCONV_OPTIONCONTAINER_H
#define _POCONV_OPTIONCONTAINER_H

#include  <basic.h>

namespace PoConv {

// ------------------------------------------------------ class OptionContainer
class OptionContainer {
  public:
    // construcntor
    OptionContainer(int argc, ::TC** argv);

    // destructor
    ~OptionContainer();

    // ���ϥե�����ѥ�����
    const ::TC* getInputPath() const;

    // ���ϥե�����ѥ�����
    const ::TC* getOutputPath() const;

  private:
    int     argNum_;
    ::TC**  argVal_;
};

} // namespace PoConv

#endif  // _POCONV_OPTIONCONTAINER_H
