//
//	Compression.h (poconv/����(zlib ������))
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#ifndef _POCONV_COMPRESSION_H
#define _POCONV_COMPRESSION_H

#include  <zlib.h>

namespace PoConv {

// ---------------------------------------------------------- class Compression
class Compression {
  public:
    // constructor
    Compression();

    // destructor
    ~Compression();

    // �ǡ����ɲ�
    bool  append(const void* bytes, unsigned int len);

    // ���̽�λ
    bool  finish();

    // �ǡ�������
    const void* bytes() const;
    const unsigned int length() const;

    // �����Ѥ�
    void  clear(unsigned int len);

  private:
    ::z_stream zstrm;
    unsigned char* buffer_;             // ��ȥХåե�
};

} // namespace PoConv
#endif  // _POCONV_COMPRESSION_H
