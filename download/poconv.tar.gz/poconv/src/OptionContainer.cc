//
//	OptionContainer.cc (poconv/Application Main)
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#include  "OptionContainer.h"
#include  "Exception.h"

namespace PoConv {

// --------------------------------------------- OptionContainer �� public �ؿ�
//
// construcntor
//
OptionContainer::OptionContainer(int argc, ::TC** argv)
  : argNum_(argc),
    argVal_(argv)
{
  if (argc < 3) {
    throw Exception("Invalid CommandLine Argument", ER_PAR);
  }
}


//
// destructor
//
OptionContainer::~OptionContainer()
{
  // ���⤷�ʤ�
  ;
}


//
// ���ϥե�����ѥ�����
//
const ::TC* OptionContainer::getInputPath() const
{
  return argVal_[1];
}


//
// ���ϥե�����ѥ�����
//
const ::TC* OptionContainer::getOutputPath() const
{
  return argVal_[2];
}

} // namespace PoConv
