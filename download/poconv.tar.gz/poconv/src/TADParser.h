//
//	TADParser.h (poconv/TAD �ѡ���)
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#ifndef _POCONV_TADPARSER_H
#define _POCONV_TADPARSER_H

#include  "BufferContainer.h"
#include  "Units.h"

namespace PoConv {

// ------------------------------------------------------------ class TADParser
class TADParser {
  public:
    // constructor
    TADParser(::UH subType, BufferContainer& reader);

    // destructor
    ~TADParser();

    // ����
    void  main();

    // ��̼���
    void  getResult(UnitContainer& cont);
    ::UNITS getHUnit() const { return hUnit_; }
    ::UNITS getVUnit() const { return vUnit_; }

  private:
    const ::UH  subType_;
    BufferContainer& reader_;
    UnitFactory&  factory_;
    UnitContainer container_;
    UnitImageLayer* current_;
    ::UNITS hUnit_;
    ::UNITS vUnit_;
    bool  isReadPalette_;
    bool  isReadAttribute_;
    ::COLOR color_[256];
    bool  trans_[256];
    bool  drop_[256];
    bool  mask_[256];

    // �����ؿ�
    void  procTS_FIG(::UW length);
    void  procTS_FIGEND(::UW length);
    void  procTS_IMAGE(::UW length);
    void  procTS_FAPPL(::UW length);
    void  procColorPattern(::UW length);
    void  procLayerName(::UW length);
    void  procPaletteAttribute(::UW length);

    // �ѥ�å����Ǥ�����
    void  createPalette();
};

} // namespace PoConv

#endif  // _POCONV_TADPARSER_H
