//
//	InputFile.h (poconv/���ϥե��������)
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#ifndef _POCONV_INPUTFILE_H
#define _POCONV_INPUTFILE_H

#include  "BufferContainer.h"

namespace PoConv {

// ------------------------------------------------------------ class InputFile
class InputFile {
  public:
    // constructor
    InputFile(const ::TC* path);

    // destructor
    ~InputFile();

    // TAD ��쥳���ɤ� parse
    bool  parseRecord();

    // 1�쥳�����ɤ߼��
    ::UH  readRecord();

    // �Хåե�����
    BufferContainer& getBuffer() { return buffer_; }

  private:
    ::W     mode_;
    ::W     fd_;
    ::LINK  link_;
    BufferContainer buffer_;
};

} // namespace PoConv

#endif  // _POCONV_INPUTFILE_H
