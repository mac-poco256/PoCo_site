//
//	Compression.cc (poconv/����(zlib ������))
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#include  "Compression.h"

#include  <basic.h>
#include  <bstdlib.h>
#include  <bstring.h>

#include  "Exception.h"

namespace PoConv {

// �������
static const unsigned int BUFFER_SIZE = 8192;

// ------------------------------------------------- Compression �� public �ؿ�
//
// constructor
//
Compression::Compression()
  : buffer_(0)
{
  ::memset(&zstrm, 0x00, sizeof(::z_stream));

  // ��ȥХåե�����
  buffer_ = new unsigned char[BUFFER_SIZE];

  // zlib �����
  zstrm.avail_out = BUFFER_SIZE;
  zstrm.next_out = buffer_;
  try {
    int z_er(::deflateInit(&zstrm, Z_BEST_COMPRESSION));
    if (z_er < Z_OK) {
      throw Exception("deflateInit()", z_er);
    }
  } catch (...){
    delete[] buffer_;
  }
}


//
// destructor
//
Compression::~Compression()
{
  // zlib ��λ
  ::deflateEnd(&zstrm);

  // ��ȥХåե�����
  delete[] buffer_;
}


//
// �ǡ����ɲ�
//
// �֤��� : true  : ���̷�³
//          false : ���̽�λ
//
bool  Compression::append(const void* bytes, unsigned int len)
{
  bool  isContinue(false);

  // z_stream ����
  if ((bytes != 0) && (len > 0)) {
    zstrm.avail_in = len;
    zstrm.next_in = static_cast<Bytef*>(const_cast<void*>(bytes));
  }

  // ���̼¹�
  int z_er(::deflate(&zstrm, Z_SYNC_FLUSH));
  if (z_er == Z_OK) {
    isContinue = (zstrm.avail_in != 0);
  } else if (z_er == Z_STREAM_END) {
    ;
  } else {
    throw Exception("deflate(Z_SYNC_FLUSH)", z_er);
  }

  return isContinue;
}


//
// ���̽�λ
//
// �֤��� : true  : ���̷�³
//          false : ���̽�λ
//
bool  Compression::finish()
{
  bool  isContinue(false);

  // Z_FINISH ȯ��
  int z_er(::deflate(&zstrm, Z_FINISH));
  if (z_er == Z_OK) {
    isContinue = true;
  } else if (z_er == Z_STREAM_END) {
    ;
  } else {
    throw Exception("deflate(Z_FINISH)", z_er);
  }

  return isContinue;
}


//
// �ǡ�������
//
const void* Compression::bytes() const
{
  return buffer_;
}


//
// �ǡ�������
//
const unsigned int Compression::length() const
{
  return (BUFFER_SIZE - zstrm.avail_out);
}


//
// �����Ѥ�
//
void  Compression::clear(unsigned int len)
{
  zstrm.avail_out += len;
  zstrm.next_out -= len;

  return;
}

} // namespace PoConv
