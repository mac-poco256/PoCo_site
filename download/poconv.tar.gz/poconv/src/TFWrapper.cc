//
//	TFWrapper.cc (poconv/libtf wrapper)
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#include  "TFWrapper.h"

#include  <btron/tf.h>
#include  <bstring.h>

#include  "Exception.h"

namespace PoConv {

static const unsigned int  BUFFER_SIZE = 1024;

// --------------------------------------------------- TFWrapper �� public �ؿ�
//
// constructor
//
TFWrapper::TFWrapper()
  : ctx_(0),
    buffer_(0), length_(0), refer_(0)
{
  // libtf �����
  ::ERR er(::tf_open_ctx(&ctx_));
  if (er < ER_OK) {
    throw Exception("tf_open_ctx()", er);
  }

  // ��ȥХåե�����
  try {
    buffer_ = new unsigned char[BUFFER_SIZE];
  } catch (...) {
    ::tf_close_ctx(ctx_);
    throw;
  }
}


//
// destructor
//
TFWrapper::~TFWrapper()
{
  // ��ȥХåե�����
  delete[] buffer_;

  // libtf ��λ
  ::tf_close_ctx(ctx_);
}


//
// ID ����
//
::W TFWrapper::getID(::W id, const char* str) const
{
  ::WERR rv(::tf_to_id(id, str));
  if (rv < ER_OK) {
    throw Exception("tf_to_id()", rv);
  }

  return static_cast< ::W>(rv);
}


//
// �Ѵ�����
//
void  TFWrapper::setConvertTo(const char* str)
{
  // profile ����
  ::ERR er(::tf_set_profile(ctx_, getID(TF_ID_PROFSET_CONVERTTO, str)));
  if (er < ER_OK) {
    throw Exception("tf_set_profile()", er);
  }

  return;
}


//
// �Ѵ�����(option)
//
void  TFWrapper::setConvertToOption(const char* str, int val)
{
  // option ����
  ::ERR er(::tf_set_options(ctx_, getID(TF_ID_OPT_CONVERT, str), val));
  if (er < ER_OK) {
    throw Exception("tf_set_profile()", er);
  }

  return;
}


//
// �Ѵ�
//
bool  TFWrapper::append(const void* data, int len)
{
  // ������ʣ��
  if (refer_ < length_) {
    ::memmove(buffer_, buffer_ + refer_, length_ - refer_);
  }
  length_ -= refer_;
  refer_ = 0;

  // �Ѵ�
  ::W dlen(static_cast< ::W>(BUFFER_SIZE - length_));
  ::WERR  rv(::tf_tcstostr(ctx_, static_cast< ::TC*>(const_cast<void*>(data)), len, 0, 0, buffer_ + length_, &dlen));
  if (rv < ER_OK) {
    throw Exception("tf_tcstostr()", rv);
  }
  length_ += dlen;

  return (rv != 0);
}


//
// ����
//
void  TFWrapper::clear(unsigned int len)
{
  refer_ += len;

  return;
}

} // namespace PoConv
