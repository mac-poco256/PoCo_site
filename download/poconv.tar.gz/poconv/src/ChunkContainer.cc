//
//	ChunkContainer.cc (poconv/PNG Chunk �ݻ�)
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#include  "ChunkContainer.h"

#include  <basic.h>
#include  <bstdlib.h>
#include  <bstring.h>
#include  <zlib.h>

#include  "Exception.h"

namespace PoConv {

// �����ޥ���
#define swapUW(i) ((((i) & 0xff000000) >> 24) | \
                   (((i) & 0x00ff0000) >>  8) | \
                   (((i) & 0x0000ff00) <<  8) | \
                   (((i) & 0x000000ff) << 24))

// �������
static const unsigned int BUFFER_SIZE = 4096;

// ---------------------------------------------- ChunkContainer �� public �ؿ�
//
// constructor
//
ChunkContainer::ChunkContainer(const char* name)
  : name_(name),
    length_(0), body_(0), size_(0)
{
  // ���⤷�ʤ�
  ;
}


//
// destructor
//
ChunkContainer::~ChunkContainer()
{
  if (body_ != 0) {
    ::free(body_);
  }
}


//
// �ǡ����ɲ�(1�Х���)
//
void  ChunkContainer::appendByte(const unsigned char val)
{
  appendData(&val, sizeof(unsigned char));

  return;
}


//
// �ǡ����ɲ�(4�Х���)
//
void  ChunkContainer::appendInt(const unsigned int val)
{
  const unsigned int i(swapUW(val));

  appendData(&i, sizeof(unsigned int));

  return;
}


//
// �ǡ����ɲ�(Ǥ��)
//
void  ChunkContainer::appendData(const void* bytes, unsigned int len)
{
  // �Хåե���ĥ
  while (size_ < (length_ + len)) {
    // �Ƴ���
    unsigned char* ptr(static_cast<unsigned char*>(::realloc(body_, size_ + BUFFER_SIZE)));
    if (ptr == 0) {
      throw Exception("memory allocation error.", ER_NOMEM);
    }

    // ����
    body_ = ptr;
    size_ += BUFFER_SIZE;
  }

  // ʣ��
  ::memcpy(&body_[length_], bytes, len);
  length_ += len;

  return;
}


//
// CHUNK Ĺ������
//
const unsigned int ChunkContainer::length(bool swap) const
{
  return (swap) ? (swapUW(length_)) : length_;
}


//
// CRC ����
//
const unsigned int ChunkContainer::crc(bool swap) const
{
  unsigned int crc(0);

  // �����
  crc = ::crc32(0, 0, 0);

  // CHUNK ������̾
  crc = ::crc32(crc, reinterpret_cast<const Bytef*>(name_), 4);

  // CHUNK body
  if (length_ > 0) {
    crc = ::crc32(crc, body_, length_);
  }

  return (swap) ? swapUW(crc) : crc;
}

} // namespace PoConv
