//
//	AppMain.h (poconv/Application Main)
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#ifndef _POCONV_APPMAIN_H
#define _POCONV_APPMAIN_H

#include  <basic.h>

#include  "OptionContainer.h"
#include  "Units.h"

namespace PoConv {

// -------------------------------------------------------------- class AppMain
class AppMain {
  public:
    // constructor
    AppMain(int argc, ::TC** argv);

    // destructor
    ~AppMain();

    // �¹�
    void  main();

  private:
    OptionContainer option_;
    UnitContainer   container_;
    ::UNITS hUnit_;
    ::UNITS vUnit_;

    // �ɤ߹���
    void  input();

    // �񤭹���
    void  output();
};

} // namespace PoConv

#endif  // _POCONV_APPMAIN_H
