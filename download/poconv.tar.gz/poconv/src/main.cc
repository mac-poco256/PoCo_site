//
//	main.cc (poconv/�ᥤ��)
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#include  <basic.h>
#include  <bstdio.h>
#include  <bstdlib.h>

#include  "AppMain.h"
#include  "Exception.h"

// ----------------------------------------------------------------------- main
//
// main
//
int main(int argc, TC** argv)
{
  ERR rv;

  rv = ER_OK;

#ifdef  DEBUG
  malloctest(1);
  Smalloctest(1);
#endif  // DEBUG

  try {
    PoConv::AppMain(argc, argv).main();
  } catch (std::bad_alloc) {
    rv = ER_NOMEM;
    printf("memory allocation error.\n");
  } catch (PoConv::Exception& err) {
    rv = err.getErr();
    printf("%s : %d(0x%08x)\n", err.getMessage(), rv, rv);
  } catch (...) {
    printf("unknown expcetion.\n");
  }

  // unit factory �����
  PoConv::UnitFactory::cleanup();

  return rv;
}
