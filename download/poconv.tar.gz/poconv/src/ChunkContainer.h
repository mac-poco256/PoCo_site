//
//	ChunkContainer.h (poconv/PNG Chunk �ݻ�)
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#ifndef _POCONV_CHUNKCONTAINER_H
#define _POCONV_CHUNKCONTAINER_H

namespace PoConv {

// ------------------------------------------------------- class ChunkContainer
class ChunkContainer {
  public:
    // constructor
    ChunkContainer(const char* name);

    // destructor
    ~ChunkContainer();

    // �ǡ����ɲ�
    void  appendByte(const unsigned char val);
    void  appendInt(const unsigned int val);
    void  appendData(const void* bytes, unsigned int len);

    // CHUNK ������̾����
    const char* name() const { return name_; }

    // CHUNK Ĺ������(swap == true : endian �Ѵ�����)
    const unsigned int length(bool swap = false) const;

    // CHUNK body ����
    const void* bytes() const { return body_; }

    // CRC ����(swap == true : endian �Ѵ�����)
    const unsigned int crc(bool swap = false) const;

  private:
    const char* name_;
    unsigned int length_;
    unsigned char* body_;
    unsigned int size_;
};

} // namespace PoConv

#endif  // _POCONV_CHUNKCONTAINER_H
