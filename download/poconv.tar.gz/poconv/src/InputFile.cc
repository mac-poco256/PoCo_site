//
//	InputFile.cc (poconv/���ϥե��������)
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#include  "InputFile.h"

#include  "Exception.h"

namespace PoConv {

// --------------------------------------------------- InputFile �� public �ؿ�
//
// constructor
//
InputFile::InputFile(const ::TC* path)
  : mode_(F_TOPEND), fd_(-1), buffer_()
{
  // LINK ����
  ::WERR  rv(::get_lnk(const_cast< ::TC*>(path), &link_, F_NORM));
  if (rv < ER_OK) {
    throw Exception("can't get InputFile Link.", rv);
  }

  // file open
  fd_ = ::opn_fil(&link_, F_READ, TNULL);
  if (fd_ < ER_OK) {
    throw Exception("can't open file.", rv);
  }
}


//
// destructor
//
InputFile::~InputFile()
{
  if (fd_ >= 0) {
    ::cls_fil(fd_);
  }
}


//
// TAD ��쥳���ɤ� parse
//
bool  InputFile::parseRecord()
{
  bool  flag(false);

  ::WERR  rv(::fnd_rec(fd_, mode_, RM_TADDATA, 0, 0));
  if (rv == ER_REC) {
    // ��ü��ã
    ;
  } else if (rv < ER_OK) {
    throw Exception("can't seek record.", rv);
  } else {
    flag = true;
    mode_ = F_NFWD;
  }

  return flag;
}


//
// �쥳�����ɤ߹���
//
// current record ���Τ��ɤ߼��
//
::UH  InputFile::readRecord()
{
  ::UH    subType;
  ::W     size;
  ::WERR  rv;

  // ����������
  rv = ::rea_rec(fd_, 0, 0, 0, &size, 0);
  if (rv < ER_OK) {
    throw Exception("can't get record size.", rv);
  }

  // �Хåե�������
  buffer_.reset();
  buffer_.resize(size);

  // �ɤ߹���
  rv = ::rea_rec(fd_, 0, static_cast< ::B*>(buffer_.bytes()), size, 0, &subType);
  if (rv < ER_OK) {
    throw Exception("can't read record.", rv);
  }

  return subType;
}

} // namespace PoConv
