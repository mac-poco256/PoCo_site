//
//	LayerUnificate.h (poconv/�쥤�䡼����)
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#ifndef _POCONV_LAYERUNIFICATE_H
#define _POCONV_LAYERUNIFICATE_H

namespace PoConv {

class UnitContainer;

// ------------------------------------------------------- class LayerUnificate
class LayerUnificate {
  public:
    // constructor
    LayerUnificate(UnitContainer& cont);

    // destructor
    ~LayerUnificate();

    // ����
    void  create();

    // ����
    const unsigned char* bytes() const { return pixelMap_; }

  private:
    UnitContainer& container_;
    unsigned char* pixelMap_;
};

} // namespace PoConv

#endif  // _POCONV_LAYERUNIFICATE_H


