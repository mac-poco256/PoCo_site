//
//	LayerUnificate.cc (poconv/�쥤�䡼����)
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#include  "LayerUnificate.h"

#include  <bstdio.h>

#include  "Units.h"

namespace PoConv {

// ------------------------------------------------------- class LayerUnificate
//
// constructor
//
LayerUnificate::LayerUnificate(UnitContainer& cont)
  : container_(cont), pixelMap_(0)
{
  UnitImageLayer* unit(static_cast<UnitImageLayer*>(*(container_.getBeginLayer())));

  // pixelmap �����
  const unsigned int size(unit->getWidth() * unit->getHeight());
  pixelMap_ = new unsigned char[size];
  ::memset(pixelMap_, 0x00, size);
}


//
// destructor
//
LayerUnificate::~LayerUnificate()
{
  delete[] pixelMap_;
}


//
// ����
//
void  LayerUnificate::create()
{
  printf("layer unificating.\n");

  UnitImageLayer* top(static_cast<UnitImageLayer*>(*(container_.getBeginLayer())));
  const unsigned int width(top->getWidth());
  const unsigned int height(top->getHeight());
  const unsigned int rowBytes(width + (width & 1));

  for (UnitContainer::Iter iter(container_.getBeginLayer());
       iter != container_.getEndLayer();
       iter = container_.getNextLayer(iter)) {
    UnitImageLayer* layer(static_cast<UnitImageLayer*>(*iter));

    if (layer->getVisible()) {
      const unsigned char* src(layer->getPixelMap());
      for (unsigned int y(0); y < height; ++y) {
        unsigned int si(y * rowBytes);
        unsigned int di(y * width);
        for (unsigned int x(0); x < width; ++x, ++si, ++di) {
          if (!(container_.getColor(src[si])->getTrans())) {
            pixelMap_[di] = src[si];
          }
        }
      }
    }
  }

  return;
}

} // namespace PoConv
