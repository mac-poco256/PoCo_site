//
//	BufferContainer.cc (poconv/��ȥХåե�����)
//
//	Copyright (C) 2008 KAENRYUU Koutoku.
//

#include  "BufferContainer.h"

#include  <bstdlib.h>

#include  "Exception.h"

namespace PoConv {

// --------------------------------------------- BufferContainer �� public �ؿ�
//
// constructor
//
BufferContainer::BufferContainer()
  : len_(0), size_(0), current_(0), buffer_(0)
{
  // ���⤷�ʤ�
  ;
}


//
// destructor
//
BufferContainer::~BufferContainer()
{
  if (free != 0) {
    ::free(buffer_);
  }
}


//
// �ꥻ�å�
//
void  BufferContainer::reset()
{
  current_ = 0;

  return;
}


//
// �Хåե���������
//
void  BufferContainer::resize(::W size)
{
  if (size_ < size) {
    // �Ƴ���
    unsigned char* ptr(static_cast<unsigned char*>(::realloc(buffer_, size)));
    if (ptr == 0) {
      throw Exception("memory allocation error.", ER_NOMEM);
    }

    // ����
    buffer_ = ptr;
    size_ = size;
  }
  len_ = size;

  return;
}


//
// �ɤ߹���(Ǥ��)
//
bool  BufferContainer::read(void* bytes, ::W length, ::W* readed)
{
  bool  flag(false);

  if (length > 0) {
    // ���̻���
    if ((len_ - current_) < length) {
      length = len_ - current_;
    }

    if (length > 0) {
      // ʣ��
      if (bytes != 0) {
        ::memcpy(bytes, &buffer_[current_], length);
      }

      // ����
      current_ += length;

      // ����
      flag = true;
      if (readed != 0) {
        *readed = length;
      }
    }
  } else {
    flag = true;
  }

  return flag;
}

} // namespace PoConv
