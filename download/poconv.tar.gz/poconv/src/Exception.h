//
//	Exception.h (poconv/�㳰���)
//
//	Copyright (C) 2008 KAENRYUU Koutoku
//

#ifndef _POCONV_EXCEPTION_H
#define _POCONV_EXCEPTION_H

#include  <basic.h>
#include  <btron/btron.h>
#include  <errcode.h>

#include  <exception>

namespace PoConv {

// ------------------------------------------------------------ class Exception
class Exception : public std::exception {
  public:
    // constructor
    Exception(const char* msg = "\0", ERR er = ER_OK)
      : exception(), message_(msg), err_(er) { }

    // destructor
    ~Exception() { }

    // ��å���������
    const char* getMessage() const { return message_; }

    // ���顼�����ɼ���
    ERR getErr() const { return err_; }

  private:
    const char* message_;
    ERR err_;
};

} // namespace PoConv

#endif  // _POCONV_EXCEPTION_H
