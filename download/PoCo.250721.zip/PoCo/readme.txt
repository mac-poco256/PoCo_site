README
--------
PoCo.app version 1.5.0 of Monday, 21st July, 2025.

The PoCo.app is developed by KAENRYUU Koutoku, since 2005.
Of course, the author and the copyright owner of this application is KAENRYUU Koutoku.

This application is Free Software which means that does not occur any fee.
The author provides this application for everyone, but without warranty of any kind.
Also, the author assumes no liability for damages.
For more information (including manuals), please visit http://www.poco256.org/ (for Japanese) or http://www.poco256.org/en/ (for not Japanese).


Thank you.




README_ja
--------
2025年07月21日（月）の PoCo.app Version 1.5.0 です。

PoCo.app は KAENRYUU Koutoku が2005年から開発しています。
もちろん、作者および著作権者は KAENRYUU Koutoku です。

このアプリケーションはフリーソフトウェアであり、如何なる利用料は発生しません。
作者はこのアプリケーションをすべての人に向けて提供していますが、如何なる種類の保証は伴っていません。
また、作者は賠償責任も負わないものとします。
（マニュアルも含めて）より詳しくは http://www.poco256.org/（日本語）あるいは http://www.poco256.org/en/（日本語以外）を参照してください。


以上。

--------2025/ 7/21(Mon.) - KAENRYUU Koutoku.
pocosup@harukago.sakura.ne.jp    http://www.poco256.org/
